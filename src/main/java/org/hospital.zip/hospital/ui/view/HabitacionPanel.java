package org.hospital.ui.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

import org.hospital.internacion.Cama;
import org.hospital.internacion.Habitacion;

/**
 * View panel for Habitacion (Room) CRUD operations.
 */
public class HabitacionPanel extends JPanel {
    // Tabla y modelo de HABITACIONES
    private JTable table;
    private DefaultTableModel tableModel;

    // Campos de formulario de HABITACION
    private JTextField txtNroHabitacion;
    private JTextField txtPiso;
    private JComboBox<String> cmbOrientacion;
    private JTextField txtIdSector;

    // Botones de HABITACION
    private JButton btnCreate;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnRefresh;
    private JButton btnClear;

    // === CAMAS ===
    // Tabla y modelo de CAMAS
    private JTable tableCamas;
    private DefaultTableModel camasTableModel;

    // Campos y botones de CAMAS
    private JTextField txtNroCama;
    private JButton btnAddCama;
    private JButton btnDeleteCama;

    public HabitacionPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Parte superior: formulario de habitación
        add(createFormPanel(), BorderLayout.NORTH);
        // Centro: tabla de habitaciones
        add(createTablePanel(), BorderLayout.CENTER);
        // Derecha: panel de camas
        add(createCamasPanel(), BorderLayout.EAST);
    }

    /** Panel de formulario de HABITACION (arriba) */
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Habitación"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nro Habitacion
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nro Habitación:"), gbc);
        gbc.gridx = 1;
        txtNroHabitacion = new JTextField(10);
        txtNroHabitacion.setEditable(false);
        panel.add(txtNroHabitacion, gbc);

        // Piso
        gbc.gridx = 2; gbc.gridy = 0;
        panel.add(new JLabel("Piso:"), gbc);
        gbc.gridx = 3;
        txtPiso = new JTextField(10);
        panel.add(txtPiso, gbc);

        // Orientacion
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Orientación:"), gbc);
        gbc.gridx = 1;
        cmbOrientacion = new JComboBox<>(new String[]{"NORTE", "SUR", "ESTE", "OESTE"});
        panel.add(cmbOrientacion, gbc);

        // ID Sector
        gbc.gridx = 2; gbc.gridy = 1;
        panel.add(new JLabel("ID Sector:"), gbc);
        gbc.gridx = 3;
        txtIdSector = new JTextField(10);
        panel.add(txtIdSector, gbc);

        // Botones de habitación
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnCreate  = new JButton("Create");
        btnUpdate  = new JButton("Update");
        btnDelete  = new JButton("Delete");
        btnClear   = new JButton("Clear");
        btnRefresh = new JButton("Refresh");

        buttonPanel.add(btnCreate);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 4;
        panel.add(buttonPanel, gbc);

        return panel;
    }

    /** Panel con tabla de HABITACIONES (centro) */
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Habitaciones"));

        String[] columnNames = {"Nro", "Piso", "Orientación", "Sector"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    /** Panel derecho: gestión de CAMAS de la habitación seleccionada */
    private JPanel createCamasPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Camas de la habitación seleccionada"));

        // --- Formulario de cama (arriba del panel de camas)
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Nro Cama:"), gbc);
        gbc.gridx = 1;
        txtNroCama = new JTextField(8);
        form.add(txtNroCama, gbc);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnAddCama = new JButton("Add Cama");
        btnDeleteCama = new JButton("Delete Cama");
        btnPanel.add(btnAddCama);
        btnPanel.add(btnDeleteCama);

        gbc.gridx = 0; gbc.gridy = 1;
        gbc.gridwidth = 2;
        form.add(btnPanel, gbc);

        panel.add(form, BorderLayout.NORTH);

        // --- Tabla de camas (abajo)
        camasTableModel = new DefaultTableModel(
                new Object[]{"Nro Cama", "Estado"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableCamas = new JTable(camasTableModel);
        tableCamas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollCamas = new JScrollPane(tableCamas);
        panel.add(scrollCamas, BorderLayout.CENTER);

        return panel;
    }

    // ================== HABITACIONES ==================

    public void updateTable(List<Habitacion> habitaciones) {
        tableModel.setRowCount(0);
        if (habitaciones == null) return;

        for (Habitacion h : habitaciones) {
            tableModel.addRow(new Object[]{
                    h.getNroHabitacion(),
                    h.getPiso(),
                    h.getOrientacion(),
                    h.getIdSector()
            });
        }
    }

    public void loadSelectedToForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        setNroHabitacion(tableModel.getValueAt(row, 0).toString());
        setPiso(tableModel.getValueAt(row, 1).toString());
        setOrientacion((String) tableModel.getValueAt(row, 2));
        setIdSector(tableModel.getValueAt(row, 3).toString());
    }

    // Getters/setters de campos de habitación
    public String getNroHabitacion() { return txtNroHabitacion.getText().trim(); }
    public String getPiso() { return txtPiso.getText().trim(); }
    public String getOrientacion() { return (String) cmbOrientacion.getSelectedItem(); }
    public String getIdSector() { return txtIdSector.getText().trim(); }

    public void setNroHabitacion(String value) { txtNroHabitacion.setText(value); }
    public void setPiso(String value) { txtPiso.setText(value); }
    public void setOrientacion(String value) { cmbOrientacion.setSelectedItem(value); }
    public void setIdSector(String value) { txtIdSector.setText(value); }

    public void clearForm() {
        txtNroHabitacion.setText("");
        txtPiso.setText("");
        txtIdSector.setText("");
        cmbOrientacion.setSelectedIndex(0);
    }

    // Botones y tabla de HABITACION
    public JButton getBtnCreate()  { return btnCreate; }
    public JButton getBtnUpdate()  { return btnUpdate; }
    public JButton getBtnDelete()  { return btnDelete; }
    public JButton getBtnRefresh() { return btnRefresh; }
    public JButton getBtnClear()   { return btnClear; }
    public JTable getTable()       { return table; }

    // ================== CAMAS ==================

    /** Actualiza la tabla de camas de la habitación seleccionada */
    public void updateCamasTable(List<Cama> camas) {
        camasTableModel.setRowCount(0);
        if (camas == null) return;

        for (Cama c : camas) {
            camasTableModel.addRow(new Object[]{
                    c.getNroCama(),
                    c.getEstado()
            });
        }
    }

    public String getNroCama() {
        return txtNroCama.getText().trim();
    }

    public void setNroCama(String nro) {
        txtNroCama.setText(nro);
    }

    public JButton getBtnAddCama() {
        return btnAddCama;
    }

    public JButton getBtnDeleteCama() {
        return btnDeleteCama;
    }

    public JTable getTableCamas() {
        return tableCamas;
    }
}
